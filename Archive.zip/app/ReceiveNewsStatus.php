<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReceiveNewsStatus extends Model
{
    protected $table = "status_receive_news";
    public $timestamps = false;
}
