<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TrackingRewardsStatus extends Model
{
    protected $table = "status_tracking_rewards";
    public $timestamps = false;
}
