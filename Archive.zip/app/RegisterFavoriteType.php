<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RegisterFavoriteType extends Model
{
    protected $table = "register_favorite_type";
}
