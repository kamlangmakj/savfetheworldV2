<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RewardsCategory extends Model
{
    protected $table = "rewards_category";
    public $timestamps = false;
}
