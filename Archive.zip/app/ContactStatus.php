<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContactStatus extends Model
{
    protected $table = "status_contact";
    public $timestamps = false;
}
