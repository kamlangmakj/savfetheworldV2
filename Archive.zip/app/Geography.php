<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Geography extends Model
{
    protected $table = "geography";
    public $timestamps = false;z
}
