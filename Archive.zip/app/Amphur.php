<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Amphur extends Model
{
    protected $table = "amphur";
    public $timestamps = false;
}
