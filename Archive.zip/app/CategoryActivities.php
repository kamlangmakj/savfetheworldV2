<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoryActivities extends Model
{
    protected $table = "category_activities";
    public $timestamps = false;
}
