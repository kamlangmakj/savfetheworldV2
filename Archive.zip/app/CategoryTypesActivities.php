<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoryTypesActivities extends Model
{
    protected $table = "category_types_activities";
    public $timestamps = false;
}
