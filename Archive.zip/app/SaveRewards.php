<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SaveRewards extends Model
{
    protected $table = "favorite_rewards";
}
