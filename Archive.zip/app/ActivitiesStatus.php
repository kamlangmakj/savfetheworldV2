<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ActivitiesStatus extends Model
{
    protected $table = "status_join_activities";
    public $timestamps = false;
}
