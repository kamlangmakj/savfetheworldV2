<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReceiveNews extends Model
{
    protected $table = "receive_news";
}
